package pages;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.github.bonigarcia.wdm.webdriver.WebDriverBrowser;

public class HomePage {

	By byBtnCloseSubscribePopUp = By.xpath("//div[contains(@class,'close')]");
	By byBtnEnquire = By.xpath("(//button[text()='INQUIRE'])[2]");
	By byBtnAddToProject = By.xpath("(//span[text()='Add to project'])[2]");
	By byBtnCloseInquireModel = By.xpath("(//h2[@class='modal-close'])[1]");
	By byBtnCreateProject = By.xpath("(//li[@id='btn-new-project'])[2]");
	By byBtnCreateNewProject = By.xpath("//button[@type='submit']");
	By byTxtProjectname = By.xpath("//input[@name='project']");
	By byLnkNewlyCreatedProject = By.xpath("//div[@class='button-desktop']/descendant::a[@class='projects-list']");
	By byBtnCheckAvailability = By.xpath("//div[@class='project-data']/descendant::button");
	By byBtnSubmitRequest = By.xpath("//button[@class='btn btn-request']");
	By byLblThankYou = By.xpath("//div[@class='container-thank-you']/descendant::td[contains(text(),'THANK YOU')]");
	//All Form Releated Xpaths
	
	
	By byTxtFirstName = By.xpath("//input[@name='first_name']");
	By byTxtLastName = By.xpath("//input[@name='last_name']");
	By byTxtEmail = By.xpath("//input[@name='email']");
	By byTxtPickUpDate = By.xpath("//input[@name='pick_up']");
	By byBtnSelectDate = By.xpath("//td[@data-handler='selectDay']/a");
	By byTxtReturnDate = By.xpath("//input[@name='return_date']");
	By byBtnNextMonth = By.xpath("//a[@title='Next']/span");
	By byBtnSelectReturnDate = By.xpath("//td[@data-handler='selectDay']/a[@data-date='28']");
	By byBtnNext = By.xpath("//div[@class='button-desktop']/button[@class='btn btn-next']");
	WebDriver driver;
	WebDriverWait wait;

	public HomePage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 5);
	}

	public void handleSubscribePopup() {
		if (driver.findElement(byBtnCloseSubscribePopUp).isDisplayed()) {
			System.out.println("Join Pop-up is visible");
			driver.findElement(byBtnCloseSubscribePopUp).click();
			System.out.println("Closed the Subscribe Pop-Up");
		} else {
			System.out.println("Subscribe Pop-up is not visible");
		}
	}

	public void clickOnInquireButton() {
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(byBtnEnquire)));
		scrollTo(driver.findElement(byBtnEnquire), driver);
		driver.findElement(byBtnEnquire).click();
		waitForPageToLoad();
	}
	
	public void closeInquireForm()
	{
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(byBtnCloseInquireModel)));
		driver.findElement(byBtnCloseInquireModel).click();
		System.out.println("Closed the Inquire Form Pop-Up");
	}
	
	public void clickonAddToProject()
	{
		scrollTo(driver.findElement(byBtnAddToProject),driver);
		driver.findElement(byBtnAddToProject).click();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(byBtnCreateProject)));
		driver.findElement(byBtnCreateProject).click();
		waitForPageToLoad();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(byBtnCreateNewProject)));
		String projectName = "AutomationUser"+returnUniqueString();
		driver.findElement(byTxtProjectname).sendKeys(projectName);
		System.out.println("Created New Project : "+projectName);
		driver.findElement(byBtnCreateNewProject).click();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(byLnkNewlyCreatedProject)));
		driver.findElement(byLnkNewlyCreatedProject).click();
		waitForPageToLoad();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(byBtnCheckAvailability)));		
		driver.findElement(byBtnCheckAvailability).click();
		waitForPageToLoad();
		filltheRequestForAvailability(projectName);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(byBtnSubmitRequest)));		
		driver.findElement(byBtnSubmitRequest).click();
	}

	public void scrollTo(WebElement element, WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView()", element);
	}

	public void waitForPageToLoad() {
		System.out.println("Waiting for Page to Load");
		String waitResponse = ((JavascriptExecutor) driver).executeScript("return document.readyState").toString();
		while (!waitResponse.equalsIgnoreCase("complete")) {
			waitResponse = ((JavascriptExecutor) driver).executeScript("return document.readyState").toString();
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Page Loaded");

	}
	
	public String returnUniqueString()
	{
		SimpleDateFormat formatter = new SimpleDateFormat("yyMMddHHmmss");
		Date date = new Date();
		return formatter.format(date);
	}
	
	public void filltheRequestForAvailability(String projectName)
	{
		waitForPageToLoad();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(byTxtFirstName)));
		driver.findElement(byTxtFirstName).sendKeys("Automation");
		System.out.println("Entered First Name : "+driver.findElement(byTxtFirstName).getAttribute("value"));
		driver.findElement(byTxtLastName).sendKeys("User");
		System.out.println("Entered Last Name : "+driver.findElement(byTxtLastName).getAttribute("value"));
		driver.findElement(byTxtEmail).sendKeys(projectName+"@test.com");
		System.out.println("Entered Email : "+driver.findElement(byTxtEmail).getAttribute("value"));
		driver.findElement(byTxtPickUpDate).click();
		driver.findElement(byBtnSelectDate).click();
		System.out.println("Selected Date : "+driver.findElement(byTxtPickUpDate).getAttribute("value"));
		driver.findElement(byTxtReturnDate).click();
		driver.findElement(byBtnNextMonth).click();
		driver.findElement(byBtnSelectReturnDate).click();
		System.out.println("Selected Date : "+driver.findElement(byBtnSelectReturnDate).getAttribute("value"));
		driver.findElement(byBtnNext).click();
		waitForPageToLoad();
	}
	
	public void validateSuccessfullSubmissionOfRequest()
	{
		waitForPageToLoad();
		Assert.assertTrue(driver.findElement(byLblThankYou).isDisplayed());
	}
}
