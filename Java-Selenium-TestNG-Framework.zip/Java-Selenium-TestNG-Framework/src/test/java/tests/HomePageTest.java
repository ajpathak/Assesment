package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;
import pages.BasePage; 
import pages.HomePage;

public class HomePageTest extends BasePage{



	@Test
	public void AssessmentFlow() {
		HomePage homePage = new HomePage(driver);
		homePage.handleSubscribePopup();
		homePage.clickOnInquireButton();
		homePage.closeInquireForm();
		homePage.clickonAddToProject();
		homePage.validateSuccessfullSubmissionOfRequest();
		
	}

	
}
